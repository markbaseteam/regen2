What is the vegetation like?

#food #biodiversity 