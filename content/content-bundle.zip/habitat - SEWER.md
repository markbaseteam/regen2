#circularity #food #toxins 
Your local authorities inform you about the mains access for your site, the most important of which is the mighty sewer. You can always get more electric cable, but sewers are to be well thought through. If, for any reason, your site is not connected to the public sewers, you have the rare chance of taking responsibility for your own "output", by wisely choosing between a septic tank, a composting toilet and a full-on outside loo.

All of these options are to be considered carefully. The placement of every specific feature is probably going to impact the positioning of your house. Don't place poopoo above the house. If, on the other hand, you are not granted this fantastic opportunity, all that you have left is the question of being "gravitationally" well-positioned with respect to the communal collecting pipes. Remember, all liquids go down!

IS THERE A SEWAGE SYSTEM ON THE LAND? 



relate to: [[habitat - MAINS]], [[microclimate - SLOPE]], [[microclimate - SOIL]] and [[WATER]] since it can pollute it if handled improperly