#microclimate #resilience #resources


WHAT IS THE AMOUNT OF ANNUAL RAINFALL IN THE AREA?

What are the patterns of rainfall? 

What are its extremes like?


related to: [[WATER]]
