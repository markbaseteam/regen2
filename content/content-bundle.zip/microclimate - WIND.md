
#resilience 


Generally, in temperate climate areas, you want to avoid cold winter winds and welcome cooling summer breezes. High winds can be a problem for some sites and hot summer winds can be a problem in others. The cold winds can come from a gully, a large valley, or just straight from the North side of your site. Most weather apps will show you the direction of the wind at any particular time. For prevailing winds though, your country may or may not have a database. Look for "prevailing wind" or "wind rose" (it's like our sector map, but with winds).
  
The ABC surefire way to mitigate a cold wind is to create a vegetation windbreak. Using winds to their full potential is also important. Beneficial summer winds can be used across ponds for evaporation as summer cooling, and wind turbines can effectively be placed on a windy site to maximize energy gain.

WHAT IS THE PREDOMINANT WIND DIRECTION AND SPEED?

-----
related to: [[microclimate - Extremes]], [[microclimate - FIRE]]
