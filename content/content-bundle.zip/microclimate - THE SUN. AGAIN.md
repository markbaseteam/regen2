#microclimate #bioclimatic #Renewable


We have already talked about the Sun. It was the first item on the very first chapter. Having a house that lacks Sun exposure in the winter or the afternoons can be heart-sinking. I lived in one for two winters, so I speak from experience. All the bio-climatic approach thing is linked to the Sun in all of its states. The very positioning of the house can drastically impact the rest of the house design. It makes it easier or harder to harness the Sun’s energy.

Choosing a south-facing plot of land (in a temperate climate) is the least anyone can strive towards in implementing a Sun-smart approach. Not all plots being perfectly oriented however, clever strategies need to be implemented to bypass what a site could be lacking in exposure.
Another point to make here would be that local traditional strategies that worked fine up until fairly recently might start to backfire in the future, due to climate change. Temperate climate strategies like turning towards the sun might mean a lot of expenses in space cooling in the hotter and hotter summers to come. That is, if they are not well considered beforehand.
On this cheery, "doomsday is here, we're all gonna fry" note, let me invite you to read the next chapter.
related to: [[microclimate - THE SUN’S POSITION]],