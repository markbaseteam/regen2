Add the property limit, as clear as you can. Remember, this is a diagram, so it's ok to not be perfect.
Add the different transparency degrees of the property limits. A property limit can be fenced with an opaque structure, hedged, planted or bare.


related to: [[habitat - LEGISLATION]], [[habitat - NEIGHBORS]]