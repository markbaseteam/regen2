#tech #circularity

A lot of information you'll have to gather from the local authorities. Neighbors don't know where water pipes are. Electricity is a must, or at least the possibility of it. You can go full off- grid these days, and the tech is improving fast. So if new solar systems and cool batteries is your thing, you can build wherever your heart desires.

IS THERE NATURAL GAS PIPE ON THE LAND?

IS THERE MAINS WATER ON THE LAND? 

IS THERE INTERNET/TELEPHONE/PHONE SIGNAL?

IS THERE ELECTRICITY ON THE LAND?

related  to: [[habitat - LEGISLATION]], [[habitat - SEWER]]