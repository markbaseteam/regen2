
This is an obvious one. 

WHAT IS THE LATITUDE OF THE LAND?

-----------------------


related to: [[scale- Bioregion]], 