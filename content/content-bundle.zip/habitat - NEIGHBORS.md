#neighbors #vernacular
Even if local legislation doesn’t force you to align with the neighboring houses, you might want to consider their placement when assigning a spot to your build. Keeping the spirit of the surroundings is not only important with regards to nature but with the built environment as well. But do not, and I repeat: Do Not Build Pastiches of the local house, like middle-class Real Estate sites do. 

The other aspect is your relationship not with the buildings around you but with the people who inhabit them. Noises, peering glances, smoky barbecues you want to avoid, of course. But all too often, wanting to protect ourselves we lose community living, the stuff of civilization. We need each other, in spite of the individualistic society we live in, and it is high time we started coming back together as belonging to the same place and time.

related to: [[microclimate - Limits of the land]]

