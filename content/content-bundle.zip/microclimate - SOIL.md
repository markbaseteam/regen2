#biodiversity #food
You cannot build on bad soil. A geotechnical soil report is the one that informs you about the building possibilities of a soil and no-one else. You can't tell without digging if you have a sand sink in the middle of your site. You would probably be well advised to avoid placing your house there.
Soil type can impact the cost of construction. Once you start digging, you can encounter expensive surprises. So talk to experts in the area to know as much as you can about the soil type where you want to build. Some soil types hold water differently than others. Determine if the site is prone to flooding. Water damage is a silent killer.


WHAT IS THE GEOLOGY OF THE LAND LIKE?

-----


What is the soil health like?



related to : [[microclimate - SLOPE]] [[building parts - foundation]], [[microclimate - Vegetation]]
