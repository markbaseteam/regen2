
As with the other elements on our Site Analysis Diagram, water is a thing to both harness and protect against. In so many corners of the planet, water is a precious thing that we in the modern world have grown accustomed to wasting. We feel entitled to having water pouring out of our pipes whenever we turn the tap on, forgetting the innumerable processes that it goes through to get there and will go through as it disappears down the drain.

Some sort of water resilience should be on every new home-builder’s mind and there are simple ways to do that. They all begin, of course, with knowing what your site can offer. In the "Listen to your Land Checklist" (which you can find here), there are a couple of questions about water sources on your land. If you have a continuous water source, like a stream or a fountain, you lucky cookie, that is your starting point. But a lot of water can be harnessed from other, impermanent sources, like rain catchment systems and grey-water management. The main rule here is to get the water that hits your land to spend as much time as possible on your land and to be of as much use as possible in the process, whether for crops and garden or for toilet flushing.

Permaculture has a whole arsenal of strategies and tools to achieve the most out of every droplet of water, including my favorite: building good [[microclimate - SOIL]]. A fertile and structured soil can absorb up to ten times more water than your standard agricultural dirt. Placing a water tank and considering a grey-water purification pond are some of the other ideas to float around.

### WATER WITH A VENGEANCE
#toxins #health

The second aspect of our house’s relationship with water is its destructive power. Water is a most perverse enemy of buildings, creeping in undetected and wrecking havoc in the hardest to repair ways.

Water weapon number one is mold. Humidity in walls from a dripping gutter, lack of ventilation in wet rooms, a frozen pipe inside a wall, the usual suspects and silent killers all use one main tool against you and that tool is mold. 

Weapon number two is the easiness with which it destroys wood structures, especially composite lumber like OSB or plywood I-joists because of their small dimensions. 
Water infiltration in basements and foundation areas can destroy structures in as little as two wet seasons and I have personally seen rain pouring into houses directly through the stone wall because it had been built inside the slope of the hill in a very heavy rain area. I shudder at the memory.

Keeping the house away from big gullies in heavy rain areas and understanding the movement of water when designing your house is smart. Stay above water. Having a clear view of what your site has to offer with regards to water management and water damage avoidance is the first step to a good dry house.
#stormwater #resilience

ONE MORE THING ON WATER

Water freezes. For building foundations it's important to know the local level of frost line. You can look it up online or with your local administration. 
Also, water floods. Flood lines will show up on your land's papers anyway, but I thought it should be said anyway.


IS THERE A NATURAL WATER SOURCE?


IS THAT WATER SOURCE AVAILABLE ALL YEAR ROUND OR DOES IT DRY UP IN THE SUMMER? 


---
related to:
[[microclimate - Rainfall]], [[microclimate - SLOPE]]