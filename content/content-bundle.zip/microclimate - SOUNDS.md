
#neighbors
An important element that doesn’t show up on maps and plans is the sounds and especially the noises present on a site. It can be a nice surprise to discover that there are birds chirping every morning in the linden tree in front of the house. But you would probably want to know beforehand it if it was a stone quarry chirping at 7 in the morning on a Saturday.

The issue of noises is most prevalent in densely populated areas, but even the smallest town or country road can have its own buzz. Placement of the house together with judicious planting of greenery (a #food forest, maybe?) can easily avert most inconveniences if the problem is handled from the on-set. Yes, good windows will solve any sound trouble, but that's not the point. 

Your relationship with the world outside is, and remaining open yet protected is key.

related to: [[microclimate - VIEWS]]
