
#microclimate #bioclimatic 




WHAT IS THE ORIENTATION OF THE LAND? 

-------


related to: [[microclimate - THE SUN’S POSITION]], [[microclimate - THE SUN. AGAIN]]