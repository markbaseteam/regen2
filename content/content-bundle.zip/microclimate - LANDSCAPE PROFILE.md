Hill profiles tend to develop an S-shaped curve under the constant effect of rainwater flows. The point where the curve changes from convex to concave is called a keyline point. Keyline design is a method of land design for soil and water conservation developed by Australian farmer and engineer P.A. Yeomans in the 1950's, and practiced widely throughout Australia ever since. You can find out more here.

Ancient megalithic people of England used to occupy the ridgeways of a hill. Now, the tendency of real estate developers is to go down on the flatlands. This choice has the enormous inconvenience of placing the dwelling under the frost line, and depriving it of the protection of foothill forests and convex slope. 

Cold feet and no hat...

The landscape profile also determines the water catchment strategies. Harnessing simple gravity can help immensely in water equipment efficiency (which means: "place your water tank above the house"). Water is both the main factor for erosion and building degradation and the main resource for human life.

[[microclimate - SLOPE]] [[WATER]] 
