#natural #microclimate #biodiversity 

This is more of a topic in your landscape design, but it can have an influence on the way to position your building. Adding wildlife corridors is especially nice for sites that are located either on old farming land or in large national parks, but it's so much more useful in cities, where critters have so little space. Your site might be visited by anything from hedgehogs to goats to deer to wolves. Endangered species are of course of particular importance. If they have a protection status, it's good to keep it in mind when designing. These species might need you to keep a wildlife corridor for them.
Animals that risk being a nuisance to your property, like wild boar eating your crops or eagles stealing your chickens might force you to fence in parts of your land. You can keep some elements closer to the house, where they are less vulnerable. Keeping a dog is always a good idea, though an eagle might find your Spitz more appetizing than threatening.
A lot of tiny native birds and critters can be encouraged to come in to increase the biodiversity and balance the #ecosystem. Try planting dense shrubs just the way they like them or otherwise reinforcing their habitat. It helps grow biodiversity on your land and control insect infestations.

related to: [[scale- Bioregion]], [[habitat - Wisdom of Place]]
