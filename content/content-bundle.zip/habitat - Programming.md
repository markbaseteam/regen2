#social

Now we do programming.
Programming is what an architect needs to know about you before he starts designing.

FIRST, STRIP OUT THE UNESSENTIAL
We live in a culture of growth. There is never enough and no one is ever satisfied. Whenever we reach a new step in our lives we immediately look for the next one. We yearn for the more and more and more and don’t know when to stop.
New home-builders have a tendency to fall for this and our poor planet is suffering the consequences. We build too big, too wasteful, too permanent.
Self-inquiry can be a tool in the first stages of imagining a future house. Getting over perceived needs and superficial wants, we might just realize we can very well live with less. We could actually be all the happier for it.

THE SINGLE MOST SUSTAINABLE AND AFFORDABLE THING YOU CAN DO THAT NO ONE IS TELLING YOU ABOUT.

The best thing you can do for the planet is something no architect, contractor or realtor will tell you, because it doesn't bring buck. To them. A smaller home is cheaper to build, easier to maintain, cheaper to heat, cozier to live in and a lot better for the planet. we all know that.
The second best thing you can do is think for the future. A house that gets demolished in twenty years time because it can't adapt to the new context is bad for the planet. And context is changing lightning-fast these days. And concrete doesn't recycle well.

Imagine having a tiny house for yourselves as a young couple, then not having to move when the children come, then not having to move when they leave for school, then not having to leave as you grow old. It needs foresight but it can be done.

Multi-functional design and progressively evolving space planning (adaptive reuse if you want) can help you strip away the fluff and reveal the essential. That doesn’t mean compromise of comfort and happiness.

This is an exercise in stripping the superficial and protecting the essential. Much like the fluff in our minds, the fluff in our homes is keeping us from growing.

