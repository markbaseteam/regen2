#neighbors 

Here come all those elements that stand out in your site but haven't been brought up in the other steps. The place’s peculiarities and quirks, what defines your plot as its own thing. It might be an enormous bamboo grove or a very large pond, a flock of flamingos that stop by on their migration journey every year like in La Grande Bellezza, or a notable feature of the neighborhood. All of the key characteristics of the site that can be mapped out get their turn now.
