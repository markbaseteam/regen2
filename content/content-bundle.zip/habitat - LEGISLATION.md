#law

Some places might restrict the area that you can build on, or give you a minimum or maximum distance to the road or to the neighbor's house. Some areas might restrict the total surface that you can build or the total height. The mayor in your village might be very keen on self-built earthships and tiny houses on wheels, others might not. 

All of these are crucial first steps in your design process, as they are most of the time... immutable. Don’t start building your home foundations only to find out you were supposed to move a meter to the left.  

There are a lot of situations where the local legislation will be so constricting that even the basics of the build will have to be adapted. This apparent narrowing of possibilities can also be a catalyst for creativity, so don’t be afraid of strict rules in your design.

