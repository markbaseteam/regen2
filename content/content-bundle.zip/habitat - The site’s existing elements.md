

A plan or a satellite photo can't show you the reality of the site’s situation. You are the one who must fill the plan with what you see on the land. Big trees and existing buildings are the most important elements to add here, along with sudden changes in slope that you might not be able to see if you don’t have a contour map (or don't know how to read one:) ).

An existing ruin that you want to keep or the previous owner’s vegetable patch can give you precious clues about the opportunities of the land. Especially with older elements, ask yourself “Why did these people do that? Is there an unseen reason for choosing a particular location to build or to garden?” Be thoughtful in your examination of what others have done before you.


MAKE A LIST OF ANY PRE-EXISTING MAN-MADE ELEMENTS ON THE LAND (a fountain, a pergola, a vegetable patch, etc)


related to: [[microclimate - SLOPE]] [[habitat - MAINS]]