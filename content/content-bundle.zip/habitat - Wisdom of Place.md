related to: [[habitat - NEIGHBORS]]
#vernacular #neighbors 

Every place has a history of thousands of years of human relationship to the land. Generations have gathered by trial and error the best most effective ways to negotiate with nature in a way that benefits long term. Until we got oil. Then it was game over. Because we could ignore nature and just add more tech and energy. Now this strategy is kicking our butt. 

There is still data about how peoples of different lands used to do it. And that data, though not to be taken ad literam, can be a great starting point for inspired solutions. So gather all that you can in the way of #proverbs, #vernacular architecture, traditions and myths. See what you make out of them. And how do they match the new context. 

The world hasn't changed as much in the past 150 years as we want to think.