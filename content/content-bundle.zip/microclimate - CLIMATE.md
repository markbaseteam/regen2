

WHAT IS THE CLIMATE LIKE?



(as detailed a description as possible)
Use the SunLocator app


WHAT IS THE CLIMATE CHANGE PREDICTION FOR THAT AREA? (you can visit http://www.impactlab.org/map/)

related to: [[scale- Bioregion]]