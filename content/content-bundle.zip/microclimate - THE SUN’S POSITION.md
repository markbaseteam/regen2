#microclimate #natural


If you have placed your base map with the North facing upwards, like a Google map, then your South will be facing downward on your paper. The Sun’s location and your latitude inform its angles in the summer and in the winter. The lowering Sun of winter months has a smaller angle than in the summer and it's also shining less bright. Orient your house in a way that allows for direct sunlight when and where it is most beneficial.

