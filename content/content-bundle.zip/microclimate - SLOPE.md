
No site is strictly flat and the irregularities of slope impact your placement decisions. Though it is easier and easier today to build on inadequate terrain, it is so much wiser to avoid it. Highly sloped land is reluctant to accommodating people or their dwellings. Big machinery and a lot of concrete can always save the day, with palpable effect on the environment. The fact remains that it is more sensible to locate your home away from the hazardously steep hill.

In some occasions, I must admit that a particular view might be of such consequence to the whole place that it will be worth perching the castle up on a steep bit. But generally speaking, slope under 5 degrees is the way to go.

If your land is very sloped indeed and no amount of terracing or judicious placement will change that, you might consider going the “earth-sheltered” way.

WHAT IS THE SLOPE OF THE LAND?

---
related to: [[WATER]] going downstream through your land, #stormwater management, 