#beauty #neighbors 

The best view of the whole place should be given special treatment in the design process. Either spectacularly shown off from the main terrace or discretely and gradually revealed by shrubbery, the main directions of vista should be carefully placed on the Sector Map, just like the other elements, in the shape of a pie slice. You can add an eye next to it, to know what it’s about. 

Along with the best views to integrate come the views that you want to avoid, like a neighbor’s fence or an industrial building on the hill just in front. Those unavoidable elements that you would rather not see from the kitchen window every morning can be made invisible or just less in-your-face by either placing a screening element just in front, between you and it, or by not placing vista-oriented spaces where it would be impossible to avoid seeing them. So by designing mindfully in the first place.

After the unwanted views “out” there are the unwanted views “in” that you want to avert. Minding them in your design as soon as possible is the best way to get rid of snoopy neighbor glances. Streets at eye level with the bathroom and neighbor’s barbecue right above the bedroom are easy enough to avoid if you take note of them soon in the Site Analysis phase.

Don’t forget that, sometimes, it is just impossible to eliminate all unwanted views from and onto your site. But knowing what you can and cannot do from the beginning can be very helpful