
The first man-made element to go on the map is the existing main site access or the possible access ways and circulation flows. 


related to: [[microclimate - Limits of the land]]